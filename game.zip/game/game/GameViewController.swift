//
//  GameViewController.swift
//  SolievGame
//
//  Created by user on 14.10.2021.
//

import UIKit

class GameViewController: UIViewController {

    var gameTimer: Timer!
    var carPcTimer: Timer!
    var stateSemafor: Int = 1
    
    @IBOutlet weak var pcCar: UIImageView!
    @IBOutlet weak var userCar: UIImageView!
    @IBOutlet weak var finishLine: UIImageView!
    @IBOutlet weak var semaforLabel: UILabel!
    @IBOutlet weak var timerLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func startGameAction(_ sender: UIButton) {
    }
    
}
